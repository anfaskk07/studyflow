package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String,
    val subject: String,
    val title: String,
    val message: String,
    val minutesBefore: Int, // 10, 5, or 1
    val scheduledTimeStr: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)
