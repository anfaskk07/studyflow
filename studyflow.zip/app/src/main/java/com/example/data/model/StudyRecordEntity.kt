package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "study_records",
    indices = [Index(value = ["userId", "date", "subject"])]
)
data class StudyRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String,
    val subject: String,
    val date: String, // "YYYY-MM-DD"
    val targetMinutes: Int = 90,
    val completedMinutes: Int = 0,
    val status: String = "NOT_STARTED", // "NOT_STARTED", "PARTIAL", "COMPLETED"
    val notes: String = "",
    val scheduledTime: String = "10:00 AM",
    val sessionId: String = "", // Links to Timetable sessionId
    val syncedWithCloud: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
