package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "users",
    indices = [Index(value = ["pinLookupHash"], unique = true)]
)
data class UserEntity(
    @PrimaryKey
    val userId: String,
    val name: String,
    val pinHash: String, // Secure salted SHA-256 hash
    val pinSalt: String, // Cryptographic salt
    val pinLookupHash: String, // Peppered lookup hash for unique check & friend lookup without storing plaintext PIN
    val createdAt: Long = System.currentTimeMillis(),
    val isCurrent: Boolean = false,
    val streakCount: Int = 1,
    val lastStudyDate: String = "", // "YYYY-MM-DD"
    val failedAttempts: Int = 0,
    val lockoutUntilMs: Long = 0L
)
