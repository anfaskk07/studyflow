package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "chapters",
    indices = [Index(value = ["userId", "subject", "chapterNumber"])]
)
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String,
    val subject: String,
    val chapterNumber: Int,
    val chapterTitle: String,
    val status: String = "NOT_STARTED", // "NOT_STARTED", "PAUSED", "COMPLETED"
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
