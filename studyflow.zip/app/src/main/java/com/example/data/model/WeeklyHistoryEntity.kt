package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "weekly_history")
data class WeeklyHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String,
    val weekIdentifier: String, // e.g. "Oct 5 – Oct 11, 2026"
    val startDate: String,
    val endDate: String,
    val totalMinutesStudied: Int,
    val completionPercentage: Int, // e.g. 82
    val daysActive: Int, // 1 to 7
    val summary: String = "",
    val savedAt: Long = System.currentTimeMillis()
)
