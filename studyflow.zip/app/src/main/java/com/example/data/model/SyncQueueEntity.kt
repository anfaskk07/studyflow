package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sync_queue")
data class SyncQueueEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String,
    val entityType: String, // "STUDY_RECORD", "CHAPTER", "TIMETABLE", "WEEKLY_HISTORY"
    val entityId: String,
    val operation: String, // "UPSERT", "DELETE"
    val payloadJson: String,
    val createdAt: Long = System.currentTimeMillis()
)
