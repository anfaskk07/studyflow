package com.example.data

import java.security.MessageDigest
import java.security.SecureRandom

object SecurityUtils {
    private const val PEPPER = "StudyFlow_Secure_Salt_2026_xKpZ"

    fun generateSalt(): String {
        val random = SecureRandom()
        val saltBytes = ByteArray(16)
        random.nextBytes(saltBytes)
        return saltBytes.joinToString("") { "%02x".format(it) }
    }

    fun hashPin(pin: String, salt: String): String {
        val normalizedPin = pin.trim().uppercase()
        val input = "$salt:$normalizedPin:$PEPPER"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun hashPinForLookup(pin: String): String {
        // Deterministic hash for matching friend PIN lookup without storing plaintext PIN
        val normalizedPin = pin.trim().uppercase()
        val input = "LOOKUP:$normalizedPin:$PEPPER"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /**
     * Generates a composite cryptographic lookup key using both Name and PIN.
     * Prevents offline brute-forcing of short PINs by binding the search space to the user's specific name.
     */
    fun generateFriendLookupKey(name: String, pin: String): String {
        val normalizedName = name.trim().lowercase()
        val normalizedPin = pin.trim().uppercase()
        val input = "FRIEND_COMPOSITE:$normalizedName:$normalizedPin"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verifyPin(pin: String, salt: String, expectedHash: String): Boolean {
        val computed = hashPin(pin, salt)
        return MessageDigest.isEqual(computed.toByteArray(), expectedHash.toByteArray())
    }
}
