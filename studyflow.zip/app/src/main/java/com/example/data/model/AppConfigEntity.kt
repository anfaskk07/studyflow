package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_config")
data class AppConfigEntity(
    @PrimaryKey
    val id: Int = 1,
    val currentVersion: String = "2.0.0",
    val latestVersion: String = "2.1.0",
    val minimumSupportedVersion: String = "1.9.0", // e.g. versions below this are forced to update
    val updateTitle: String = "Update Available",
    val updateDescription: String = "StudyFlow 2.1 introduces timetable engine integration, secure multi-user isolation, and enhanced weekly stats.",
    val updateUrl: String = "https://play.google.com/store/apps/details?id=com.aistudio.studyflow.xkpz",
    val dismissedVersion: String = "", // Remembers if user chose "Later" for this specific version
    val isMandatory: Boolean = false
) {
    fun isUpdateAvailable(): Boolean {
        return isVersionHigher(latestVersion, currentVersion)
    }

    fun isForceUpdateRequired(): Boolean {
        return isVersionHigher(minimumSupportedVersion, currentVersion)
    }

    private fun isVersionHigher(v1: String, v2: String): Boolean {
        try {
            val parts1 = v1.split(".").map { it.toIntOrNull() ?: 0 }
            val parts2 = v2.split(".").map { it.toIntOrNull() ?: 0 }
            for (i in 0 until maxOf(parts1.size, parts2.size)) {
                val p1 = parts1.getOrElse(i) { 0 }
                val p2 = parts2.getOrElse(i) { 0 }
                if (p1 > p2) return true
                if (p1 < p2) return false
            }
        } catch (_: Exception) {
            return false
        }
        return false
    }
}
