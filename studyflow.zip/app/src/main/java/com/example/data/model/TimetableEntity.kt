package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "timetable",
    indices = [Index(value = ["userId", "dayOfWeek"])]
)
data class TimetableEntity(
    @PrimaryKey
    val sessionId: String, // UUID
    val userId: String,
    val dayOfWeek: Int, // 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday, 5 = Friday, 6 = Saturday, 7 = Sunday
    val subject: String, // e.g. "Physics", "Chemistry", "Botany", "Zoology", "Maths"
    val startTime: String, // e.g. "09:00 AM"
    val endTime: String, // e.g. "10:30 AM"
    val targetMinutes: Int = 90,
    val optionalChapter: String = "", // e.g. "Chapter 4: Moving Charges"
    val isActive: Boolean = true
)
