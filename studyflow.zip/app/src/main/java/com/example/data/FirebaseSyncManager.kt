package com.example.data

import android.content.Context
import android.util.Log
import com.example.data.model.ChapterEntity
import com.example.data.model.StudyRecordEntity
import com.example.data.model.TimetableEntity
import com.example.data.model.WeeklyHistoryEntity
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

data class PublicFriendProfile(
    val userId: String,
    val name: String,
    val streakCount: Int,
    val weeklyProgress: Int,
    val updatedAt: Long
)

class FirebaseSyncManager(private val context: Context) {

    companion object {
        private const val TAG = "FirebaseSyncManager"
        const val REQUIRED_CONFIG_MSG = "google-services.json is located in: app/google-services.json"
    }

    /**
     * Confirms that Firebase is initialized.
     * If not already initialized by FirebaseInitProvider, explicitly initializes FirebaseApp.
     */
    fun isFirebaseInitialized(): Boolean {
        return try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            FirebaseApp.getApps(context).isNotEmpty()
        } catch (e: Exception) {
            Log.w(TAG, "Firebase not initialized: ${e.message}")
            false
        }
    }

    private fun getFirestore(): FirebaseFirestore? {
        return if (isFirebaseInitialized()) {
            try {
                FirebaseFirestore.getInstance()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to get Firestore instance: ${e.message}")
                null
            }
        } else {
            null
        }
    }

    // SYNC LOCAL USER DATA TO FIRESTORE
    suspend fun uploadUserData(
        userId: String,
        name: String,
        streakCount: Int,
        pinLookupHash: String,
        records: List<StudyRecordEntity>,
        chapters: List<ChapterEntity>,
        weeklyHistory: List<WeeklyHistoryEntity>,
        timetable: List<TimetableEntity>
    ): Boolean {
        val db = getFirestore() ?: return false
        return try {
            val totalMinutes = records.sumOf { it.completedMinutes }
            val targetMinutes = records.sumOf { it.targetMinutes }.coerceAtLeast(1)
            val weeklyPct = ((totalMinutes.toDouble() / targetMinutes.toDouble()) * 100).toInt().coerceIn(0, 100)

            // 1. Upload Public Discovery Profile for Friend Lookup across phones
            // STRICT PRIVACY: NEVER contains plaintext PIN, PIN hash, salt, pepper, or private credentials!
            // Stored under 'friend_lookup' with allow list: false to prevent account enumeration.
            val publicProfile = hashMapOf(
                "userId" to userId,
                "name" to name,
                "streakCount" to streakCount,
                "weeklyProgress" to weeklyPct,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("friend_lookup").document(pinLookupHash)
                .set(publicProfile, SetOptions.merge()).await()

            // 2. Upload Study Records (partitioned under /users/{userId}/study_records/)
            for (record in records) {
                val recordData = hashMapOf(
                    "id" to record.id,
                    "userId" to record.userId,
                    "subject" to record.subject,
                    "date" to record.date,
                    "targetMinutes" to record.targetMinutes,
                    "completedMinutes" to record.completedMinutes,
                    "status" to record.status,
                    "notes" to record.notes,
                    "scheduledTime" to record.scheduledTime,
                    "sessionId" to record.sessionId,
                    "updatedAt" to record.updatedAt
                )
                db.collection("users").document(userId)
                    .collection("study_records").document(record.id.toString())
                    .set(recordData, SetOptions.merge()).await()
            }

            // 3. Upload Chapters (partitioned under /users/{userId}/chapters/)
            for (chapter in chapters) {
                val chapterData = hashMapOf(
                    "id" to chapter.id,
                    "userId" to chapter.userId,
                    "subject" to chapter.subject,
                    "chapterNumber" to chapter.chapterNumber,
                    "chapterTitle" to chapter.chapterTitle,
                    "status" to chapter.status,
                    "notes" to chapter.notes,
                    "updatedAt" to chapter.updatedAt
                )
                db.collection("users").document(userId)
                    .collection("chapters").document(chapter.id.toString())
                    .set(chapterData, SetOptions.merge()).await()
            }

            // 4. Upload Weekly History (partitioned under /users/{userId}/weekly_history/)
            for (history in weeklyHistory) {
                val historyData = hashMapOf(
                    "id" to history.id,
                    "userId" to history.userId,
                    "weekIdentifier" to history.weekIdentifier,
                    "startDate" to history.startDate,
                    "endDate" to history.endDate,
                    "totalMinutesStudied" to history.totalMinutesStudied,
                    "completionPercentage" to history.completionPercentage,
                    "daysActive" to history.daysActive,
                    "summary" to history.summary,
                    "savedAt" to history.savedAt
                )
                db.collection("users").document(userId)
                    .collection("weekly_history").document(history.id.toString())
                    .set(historyData, SetOptions.merge()).await()
            }

            // 5. Upload Timetable (partitioned under /users/{userId}/timetable/)
            for (session in timetable) {
                val sessionData = hashMapOf(
                    "sessionId" to session.sessionId,
                    "userId" to session.userId,
                    "dayOfWeek" to session.dayOfWeek,
                    "subject" to session.subject,
                    "startTime" to session.startTime,
                    "endTime" to session.endTime,
                    "targetMinutes" to session.targetMinutes,
                    "optionalChapter" to session.optionalChapter,
                    "isActive" to session.isActive
                )
                db.collection("users").document(userId)
                    .collection("timetable").document(session.sessionId)
                    .set(sessionData, SetOptions.merge()).await()
            }

            true
        } catch (e: Exception) {
            Log.e(TAG, "Error uploading user data to Firestore: ${e.message}", e)
            false
        }
    }

    // CROSS-DEVICE FRIEND LOOKUP VIA CLOUD FIRESTORE
    suspend fun lookupFriendAcrossDevices(
        friendName: String,
        friendPinLookupHash: String
    ): PublicFriendProfile? {
        val db = getFirestore() ?: return null
        return try {
            // First check friend_lookup collection
            var doc = db.collection("friend_lookup").document(friendPinLookupHash).get().await()
            if (!doc.exists()) {
                // Backward-compatibility check
                doc = db.collection("public_profiles").document(friendPinLookupHash).get().await()
            }
            if (doc.exists()) {
                val name = doc.getString("name") ?: ""
                if (name.equals(friendName.trim(), ignoreCase = true)) {
                    PublicFriendProfile(
                        userId = doc.getString("userId") ?: "",
                        name = name,
                        streakCount = (doc.getLong("streakCount") ?: 1L).toInt(),
                        weeklyProgress = (doc.getLong("weeklyProgress") ?: 0L).toInt(),
                        updatedAt = doc.getLong("updatedAt") ?: 0L
                    )
                } else null
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "Error looking up friend in Firestore: ${e.message}", e)
            null
        }
    }

    // FETCH FRIEND STUDY PROGRESS (STRICTLY READ ONLY)
    suspend fun fetchFriendStudyRecords(friendUserId: String): List<StudyRecordEntity> {
        val db = getFirestore() ?: return emptyList()
        return try {
            val snapshot = db.collection("users").document(friendUserId)
                .collection("study_records").get().await()
            snapshot.documents.mapNotNull { doc ->
                val id = doc.getLong("id") ?: return@mapNotNull null
                StudyRecordEntity(
                    id = id,
                    userId = friendUserId,
                    subject = doc.getString("subject") ?: "",
                    date = doc.getString("date") ?: "",
                    targetMinutes = (doc.getLong("targetMinutes") ?: 90L).toInt(),
                    completedMinutes = (doc.getLong("completedMinutes") ?: 0L).toInt(),
                    status = doc.getString("status") ?: "NOT_STARTED",
                    notes = doc.getString("notes") ?: "",
                    scheduledTime = doc.getString("scheduledTime") ?: "10:00 AM",
                    sessionId = doc.getString("sessionId") ?: "",
                    syncedWithCloud = true,
                    updatedAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching friend records: ${e.message}", e)
            emptyList()
        }
    }

    suspend fun fetchFriendChapters(friendUserId: String): List<ChapterEntity> {
        val db = getFirestore() ?: return emptyList()
        return try {
            val snapshot = db.collection("users").document(friendUserId)
                .collection("chapters").get().await()
            snapshot.documents.mapNotNull { doc ->
                val id = doc.getLong("id") ?: return@mapNotNull null
                ChapterEntity(
                    id = id,
                    userId = friendUserId,
                    subject = doc.getString("subject") ?: "",
                    chapterNumber = (doc.getLong("chapterNumber") ?: 1L).toInt(),
                    chapterTitle = doc.getString("chapterTitle") ?: "",
                    status = doc.getString("status") ?: "NOT_STARTED",
                    notes = doc.getString("notes") ?: "",
                    updatedAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching friend chapters: ${e.message}", e)
            emptyList()
        }
    }

    suspend fun fetchFriendWeeklyHistory(friendUserId: String): List<WeeklyHistoryEntity> {
        val db = getFirestore() ?: return emptyList()
        return try {
            val snapshot = db.collection("users").document(friendUserId)
                .collection("weekly_history").get().await()
            snapshot.documents.mapNotNull { doc ->
                val id = doc.getLong("id") ?: return@mapNotNull null
                WeeklyHistoryEntity(
                    id = id,
                    userId = friendUserId,
                    weekIdentifier = doc.getString("weekIdentifier") ?: "",
                    startDate = doc.getString("startDate") ?: "",
                    endDate = doc.getString("endDate") ?: "",
                    totalMinutesStudied = (doc.getLong("totalMinutesStudied") ?: 0L).toInt(),
                    completionPercentage = (doc.getLong("completionPercentage") ?: 0L).toInt(),
                    daysActive = (doc.getLong("daysActive") ?: 1L).toInt(),
                    summary = doc.getString("summary") ?: "",
                    savedAt = doc.getLong("savedAt") ?: System.currentTimeMillis()
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching friend weekly history: ${e.message}", e)
            emptyList()
        }
    }
}
