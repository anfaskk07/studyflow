package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppConfigEntity
import com.example.data.model.ChapterEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.StudyRecordEntity
import com.example.data.model.SyncQueueEntity
import com.example.data.model.TimetableEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserSettingsEntity
import com.example.data.model.WeeklyHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE isCurrent = 1 LIMIT 1")
    fun getCurrentUserFlow(): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE isCurrent = 1 LIMIT 1")
    suspend fun getCurrentUser(): UserEntity?

    @Query("SELECT * FROM users WHERE pinLookupHash = :hash LIMIT 1")
    suspend fun getUserByPinLookupHash(hash: String): UserEntity?

    @Query("SELECT * FROM users WHERE LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun getUserByName(name: String): UserEntity?

    @Query("SELECT * FROM users WHERE LOWER(name) = LOWER(:name) AND pinLookupHash = :hash LIMIT 1")
    suspend fun getUserByNameAndPinHash(name: String, hash: String): UserEntity?

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users")
    suspend fun getAllUsers(): List<UserEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET isCurrent = 0")
    suspend fun clearCurrentUsers()

    @Query("UPDATE users SET isCurrent = 1 WHERE userId = :userId")
    suspend fun setCurrentUser(userId: String)

    @Query("SELECT COUNT(*) FROM users")
    suspend fun getUserCount(): Int
}

@Dao
interface TimetableDao {
    @Query("SELECT * FROM timetable WHERE userId = :userId ORDER BY dayOfWeek ASC, startTime ASC")
    fun getTimetableFlow(userId: String): Flow<List<TimetableEntity>>

    @Query("SELECT * FROM timetable WHERE userId = :userId AND dayOfWeek = :dayOfWeek ORDER BY startTime ASC")
    fun getTimetableForDayFlow(userId: String, dayOfWeek: Int): Flow<List<TimetableEntity>>

    @Query("SELECT * FROM timetable WHERE userId = :userId AND dayOfWeek = :dayOfWeek ORDER BY startTime ASC")
    suspend fun getTimetableForDay(userId: String, dayOfWeek: Int): List<TimetableEntity>

    @Query("SELECT * FROM timetable WHERE userId = :userId")
    suspend fun getAllTimetable(userId: String): List<TimetableEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimetable(items: List<TimetableEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(item: TimetableEntity)

    @Update
    suspend fun updateSession(item: TimetableEntity)

    @Query("DELETE FROM timetable WHERE sessionId = :sessionId")
    suspend fun deleteSession(sessionId: String)
}

@Dao
interface StudyRecordDao {
    @Query("SELECT * FROM study_records WHERE userId = :userId AND date = :date ORDER BY id ASC")
    fun getTodayRecordsFlow(userId: String, date: String): Flow<List<StudyRecordEntity>>

    @Query("SELECT * FROM study_records WHERE userId = :userId AND date = :date")
    suspend fun getTodayRecords(userId: String, date: String): List<StudyRecordEntity>

    @Query("SELECT * FROM study_records WHERE userId = :userId AND date BETWEEN :startDate AND :endDate")
    suspend fun getRecordsInRange(userId: String, startDate: String, endDate: String): List<StudyRecordEntity>

    @Query("SELECT * FROM study_records WHERE userId = :userId")
    suspend fun getAllRecords(userId: String): List<StudyRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: StudyRecordEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecords(records: List<StudyRecordEntity>)

    @Update
    suspend fun updateRecord(record: StudyRecordEntity)

    @Query("SELECT * FROM study_records WHERE id = :id LIMIT 1")
    suspend fun getRecordById(id: Long): StudyRecordEntity?
}

@Dao
interface ChapterDao {
    @Query("SELECT * FROM chapters WHERE userId = :userId AND subject = :subject ORDER BY chapterNumber ASC")
    fun getChaptersBySubjectFlow(userId: String, subject: String): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE userId = :userId ORDER BY subject ASC, chapterNumber ASC")
    fun getAllChaptersFlow(userId: String): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE userId = :userId")
    suspend fun getAllChapters(userId: String): List<ChapterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>)

    @Update
    suspend fun updateChapter(chapter: ChapterEntity)

    @Query("SELECT * FROM chapters WHERE id = :id LIMIT 1")
    suspend fun getChapterById(id: Long): ChapterEntity?
}

@Dao
interface WeeklyHistoryDao {
    @Query("SELECT * FROM weekly_history WHERE userId = :userId ORDER BY savedAt DESC")
    fun getWeeklyHistoryFlow(userId: String): Flow<List<WeeklyHistoryEntity>>

    @Query("SELECT * FROM weekly_history WHERE userId = :userId")
    suspend fun getAllHistory(userId: String): List<WeeklyHistoryEntity>

    @Query("SELECT * FROM weekly_history WHERE userId = :userId AND weekIdentifier = :identifier LIMIT 1")
    suspend fun getHistoryByIdentifier(userId: String, identifier: String): WeeklyHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: WeeklyHistoryEntity): Long
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY timestamp DESC")
    fun getNotificationsFlow(userId: String): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllRead(userId: String)
}

@Dao
interface AppConfigDao {
    @Query("SELECT * FROM app_config WHERE id = 1 LIMIT 1")
    fun getConfigFlow(): Flow<AppConfigEntity?>

    @Query("SELECT * FROM app_config WHERE id = 1 LIMIT 1")
    suspend fun getConfig(): AppConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(config: AppConfigEntity)

    @Query("UPDATE app_config SET dismissedVersion = :version WHERE id = 1")
    suspend fun setDismissedVersion(version: String)
}

@Dao
interface UserSettingsDao {
    @Query("SELECT * FROM settings WHERE userId = :userId LIMIT 1")
    fun getSettingsFlow(userId: String): Flow<UserSettingsEntity?>

    @Query("SELECT * FROM settings WHERE userId = :userId LIMIT 1")
    suspend fun getSettings(userId: String): UserSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: UserSettingsEntity)
}

@Dao
interface SyncQueueDao {
    @Query("SELECT * FROM sync_queue WHERE userId = :userId ORDER BY createdAt ASC")
    suspend fun getPendingItems(userId: String): List<SyncQueueEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(item: SyncQueueEntity): Long

    @Query("DELETE FROM sync_queue WHERE id = :id")
    suspend fun deleteItem(id: Long)

    @Query("DELETE FROM sync_queue WHERE userId = :userId")
    suspend fun clearQueue(userId: String)
}
