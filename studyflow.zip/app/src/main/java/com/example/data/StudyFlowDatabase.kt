package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.AppConfigDao
import com.example.data.dao.ChapterDao
import com.example.data.dao.NotificationDao
import com.example.data.dao.StudyRecordDao
import com.example.data.dao.SyncQueueDao
import com.example.data.dao.TimetableDao
import com.example.data.dao.UserDao
import com.example.data.dao.UserSettingsDao
import com.example.data.dao.WeeklyHistoryDao
import com.example.data.model.AppConfigEntity
import com.example.data.model.ChapterEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.StudyRecordEntity
import com.example.data.model.SyncQueueEntity
import com.example.data.model.TimetableEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserSettingsEntity
import com.example.data.model.WeeklyHistoryEntity

@Database(
    entities = [
        UserEntity::class,
        StudyRecordEntity::class,
        ChapterEntity::class,
        WeeklyHistoryEntity::class,
        NotificationEntity::class,
        AppConfigEntity::class,
        UserSettingsEntity::class,
        TimetableEntity::class,
        SyncQueueEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class StudyFlowDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun studyRecordDao(): StudyRecordDao
    abstract fun chapterDao(): ChapterDao
    abstract fun weeklyHistoryDao(): WeeklyHistoryDao
    abstract fun notificationDao(): NotificationDao
    abstract fun appConfigDao(): AppConfigDao
    abstract fun userSettingsDao(): UserSettingsDao
    abstract fun timetableDao(): TimetableDao
    abstract fun syncQueueDao(): SyncQueueDao

    companion object {
        @Volatile
        private var INSTANCE: StudyFlowDatabase? = null

        fun getInstance(context: Context): StudyFlowDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    StudyFlowDatabase::class.java,
                    "studyflow_database"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
