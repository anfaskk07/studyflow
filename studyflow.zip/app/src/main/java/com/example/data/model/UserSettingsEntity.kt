package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "settings")
data class UserSettingsEntity(
    @PrimaryKey
    val userId: String,
    val themeMode: String = "SYSTEM", // "SYSTEM", "LIGHT", "DARK"
    val notify10Min: Boolean = true,
    val notify5Min: Boolean = true,
    val notify1Min: Boolean = true,
    val soundEnabled: Boolean = true,
    val dailyTargetMinutes: Int = 240
)
