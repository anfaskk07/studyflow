package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SecurityUtils
import com.example.data.StudyFlowRepository
import com.example.data.SyncConnectionState
import com.example.data.model.AppConfigEntity
import com.example.data.model.ChapterEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.StudyRecordEntity
import com.example.data.model.TimetableEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserSettingsEntity
import com.example.data.model.WeeklyHistoryEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

data class StudyFlowUiState(
    val currentUser: UserEntity? = null,
    val isFriendMode: Boolean = false,
    val friendUser: UserEntity? = null,
    val todayRecords: List<StudyRecordEntity> = emptyList(),
    val allChapters: List<ChapterEntity> = emptyList(),
    val timetable: List<TimetableEntity> = emptyList(),
    val weeklyHistory: List<WeeklyHistoryEntity> = emptyList(),
    val notifications: List<NotificationEntity> = emptyList(),
    val appConfig: AppConfigEntity? = null,
    val userSettings: UserSettingsEntity? = null,
    val selectedSubject: String = "Physics",
    val partialRecordToEdit: StudyRecordEntity? = null,
    val chapterToEditNotes: ChapterEntity? = null,
    val aiResponse: String? = null,
    val isAiLoading: Boolean = false,
    val isAiSheetOpen: Boolean = false,
    val isSettingsOpen: Boolean = false,
    val isWeeklyHistoryOpen: Boolean = false,
    val isAddSubjectDialogOpen: Boolean = false,
    val isAddChapterDialogOpen: Boolean = false,
    val showUpdateDialog: Boolean = false,
    val isForceUpdate: Boolean = false,
    val authError: String? = null,
    val snackbarMessage: String? = null,
    val connectionState: SyncConnectionState = SyncConnectionState.SYNCED
)

class StudyFlowViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = StudyFlowRepository(application)

    private val _uiState = MutableStateFlow(StudyFlowUiState())
    val uiState: StateFlow<StudyFlowUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeApp()
            observeCurrentUser()
            observeAppConfig()
        }
    }

    private fun observeCurrentUser() {
        viewModelScope.launch {
            repository.getCurrentUserFlow().collectLatest { user ->
                _uiState.value = _uiState.value.copy(
                    currentUser = user,
                    isFriendMode = false,
                    friendUser = null
                )
                if (user != null) {
                    loadUserData(user.userId)
                }
            }
        }
    }

    private fun observeAppConfig() {
        viewModelScope.launch {
            repository.getAppConfigFlow().collectLatest { config ->
                if (config != null) {
                    val force = config.isForceUpdateRequired()
                    val updateAvailable = config.isUpdateAvailable()
                    val dismissed = config.dismissedVersion == config.latestVersion
                    val shouldShow = force || (updateAvailable && !dismissed)

                    _uiState.value = _uiState.value.copy(
                        appConfig = config,
                        isForceUpdate = force,
                        showUpdateDialog = shouldShow
                    )
                }
            }
        }
    }

    private fun loadUserData(userId: String) {
        viewModelScope.launch {
            repository.getTodayRecordsFlow(userId).collectLatest { records ->
                _uiState.value = _uiState.value.copy(todayRecords = records)
            }
        }
        viewModelScope.launch {
            repository.getAllChaptersFlow(userId).collectLatest { chapters ->
                _uiState.value = _uiState.value.copy(allChapters = chapters)
            }
        }
        viewModelScope.launch {
            repository.getTimetableFlow(userId).collectLatest { tt ->
                _uiState.value = _uiState.value.copy(timetable = tt)
            }
        }
        viewModelScope.launch {
            repository.getWeeklyHistoryFlow(userId).collectLatest { history ->
                _uiState.value = _uiState.value.copy(weeklyHistory = history)
            }
        }
        viewModelScope.launch {
            repository.getNotificationsFlow(userId).collectLatest { notifs ->
                _uiState.value = _uiState.value.copy(notifications = notifs)
            }
        }
        viewModelScope.launch {
            repository.getUserSettingsFlow(userId).collectLatest { settings ->
                _uiState.value = _uiState.value.copy(userSettings = settings)
            }
        }
    }

    // AUTHENTICATION
    fun register(name: String, pin: String) {
        viewModelScope.launch {
            when (val result = repository.registerUser(name, pin)) {
                is StudyFlowRepository.AuthResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        currentUser = result.user,
                        isFriendMode = false,
                        authError = null,
                        snackbarMessage = "Account created. Welcome to StudyFlow, ${result.user.name}!"
                    )
                }
                is StudyFlowRepository.AuthResult.Error -> {
                    _uiState.value = _uiState.value.copy(authError = result.message)
                }
            }
        }
    }

    fun login(name: String, pin: String) {
        viewModelScope.launch {
            when (val result = repository.loginUser(name, pin)) {
                is StudyFlowRepository.AuthResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        currentUser = result.user,
                        isFriendMode = false,
                        authError = null,
                        snackbarMessage = "Welcome back, ${result.user.name}!"
                    )
                }
                is StudyFlowRepository.AuthResult.Error -> {
                    _uiState.value = _uiState.value.copy(authError = result.message)
                }
            }
        }
    }

    fun viewFriendProgress(friendName: String, friendPin: String) {
        viewModelScope.launch {
            when (val result = repository.findFriend(friendName, friendPin)) {
                is StudyFlowRepository.AuthResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        isFriendMode = true,
                        friendUser = result.user,
                        authError = null,
                        snackbarMessage = "Viewing ${result.user.name}'s StudyFlow (Read-Only)"
                    )
                    loadUserData(result.user.userId)
                }
                is StudyFlowRepository.AuthResult.Error -> {
                    _uiState.value = _uiState.value.copy(authError = result.message)
                }
            }
        }
    }

    fun exitFriendMode() {
        val current = _uiState.value.currentUser
        _uiState.value = _uiState.value.copy(
            isFriendMode = false,
            friendUser = null
        )
        if (current != null) {
            loadUserData(current.userId)
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _uiState.value = StudyFlowUiState()
        }
    }

    fun clearAuthError() {
        _uiState.value = _uiState.value.copy(authError = null)
    }

    fun clearSnackbar() {
        _uiState.value = _uiState.value.copy(snackbarMessage = null)
    }

    // SUBJECT STUDY SESSIONS (TODAY)
    fun toggleSubjectComplete(record: StudyRecordEntity) {
        if (_uiState.value.isFriendMode) {
            _uiState.value = _uiState.value.copy(snackbarMessage = "Read-Only: Cannot edit friend's dashboard.")
            return
        }
        viewModelScope.launch {
            repository.toggleSubjectCompleted(record.id)
        }
    }

    fun openPartialCompletion(record: StudyRecordEntity) {
        if (_uiState.value.isFriendMode) {
            _uiState.value = _uiState.value.copy(snackbarMessage = "Read-Only: Cannot edit friend's dashboard.")
            return
        }
        _uiState.value = _uiState.value.copy(partialRecordToEdit = record)
    }

    fun closePartialCompletion() {
        _uiState.value = _uiState.value.copy(partialRecordToEdit = null)
    }

    fun savePartialCompletion(minutes: Int, notes: String) {
        val record = _uiState.value.partialRecordToEdit ?: return
        if (_uiState.value.isFriendMode) return
        viewModelScope.launch {
            repository.savePartialCompletion(record.id, minutes, notes)
            _uiState.value = _uiState.value.copy(
                partialRecordToEdit = null,
                snackbarMessage = "Logged $minutes mins for ${record.subject}."
            )
        }
    }

    fun addSubject(subject: String, targetMinutes: Int, notes: String, time: String) {
        val user = _uiState.value.currentUser ?: return
        if (_uiState.value.isFriendMode) return
        viewModelScope.launch {
            repository.addNewSubject(user.userId, subject, targetMinutes, notes, time)
            _uiState.value = _uiState.value.copy(
                isAddSubjectDialogOpen = false,
                snackbarMessage = "Added $subject to today's schedule."
            )
        }
    }

    // CHAPTER TRACKING
    fun selectSubject(subject: String) {
        _uiState.value = _uiState.value.copy(selectedSubject = subject)
    }

    fun updateChapterStatus(chapter: ChapterEntity, newStatus: String) {
        if (_uiState.value.isFriendMode) {
            _uiState.value = _uiState.value.copy(snackbarMessage = "Read-Only: Cannot edit friend's chapters.")
            return
        }
        viewModelScope.launch {
            repository.updateChapterStatus(chapter.id, newStatus)
        }
    }

    fun openChapterNotes(chapter: ChapterEntity) {
        if (_uiState.value.isFriendMode) {
            _uiState.value = _uiState.value.copy(snackbarMessage = "Read-Only: Cannot edit friend's notes.")
            return
        }
        _uiState.value = _uiState.value.copy(chapterToEditNotes = chapter)
    }

    fun closeChapterNotes() {
        _uiState.value = _uiState.value.copy(chapterToEditNotes = null)
    }

    fun saveChapterNotes(notes: String) {
        val chapter = _uiState.value.chapterToEditNotes ?: return
        if (_uiState.value.isFriendMode) return
        viewModelScope.launch {
            repository.updateChapterNotes(chapter.id, notes)
            _uiState.value = _uiState.value.copy(
                chapterToEditNotes = null,
                snackbarMessage = "Notes updated for Ch ${chapter.chapterNumber}."
            )
        }
    }

    fun addChapter(subject: String, number: Int, title: String, notes: String) {
        val user = _uiState.value.currentUser ?: return
        if (_uiState.value.isFriendMode) return
        viewModelScope.launch {
            repository.addChapter(user.userId, subject, number, title, notes)
            _uiState.value = _uiState.value.copy(
                isAddChapterDialogOpen = false,
                snackbarMessage = "Added Chapter $number to $subject."
            )
        }
    }

    // WEEKLY HISTORY
    fun archiveWeek() {
        val user = _uiState.value.currentUser ?: return
        if (_uiState.value.isFriendMode) return
        viewModelScope.launch {
            val archived = repository.archiveCurrentWeek(user.userId)
            _uiState.value = _uiState.value.copy(
                snackbarMessage = "Archived ${archived.weekIdentifier} permanently."
            )
        }
    }

    // NOTIFICATIONS
    fun triggerTestNotification(subject: String, minutesBefore: Int) {
        val user = _uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.triggerLocalStudyReminder(user.userId, subject, minutesBefore)
            _uiState.value = _uiState.value.copy(
                snackbarMessage = "Reminder sent: $subject in $minutesBefore min."
            )
        }
    }

    // ONLINE + OFFLINE SYNCHRONIZATION
    fun syncNow() {
        val user = _uiState.value.currentUser ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(connectionState = SyncConnectionState.SYNCING)
            val state = repository.performSync(user.userId)
            _uiState.value = _uiState.value.copy(
                connectionState = state,
                snackbarMessage = if (state == SyncConnectionState.SYNCED) "Synced with cloud." else "Offline: changes queued locally."
            )
        }
    }

    // APP CONFIG & UPDATES
    fun dismissUpdate() {
        val config = _uiState.value.appConfig ?: return
        if (_uiState.value.isForceUpdate) return // cannot dismiss mandatory update
        viewModelScope.launch {
            repository.dismissUpdate(config.latestVersion)
            _uiState.value = _uiState.value.copy(showUpdateDialog = false)
        }
    }

    fun acceptUpdate() {
        _uiState.value = _uiState.value.copy(
            showUpdateDialog = false,
            snackbarMessage = "Connecting to app store for update..."
        )
    }

    // SETTINGS & EXPORT
    fun setSettingsOpen(open: Boolean) {
        _uiState.value = _uiState.value.copy(isSettingsOpen = open)
    }

    fun setWeeklyHistoryOpen(open: Boolean) {
        _uiState.value = _uiState.value.copy(isWeeklyHistoryOpen = open)
    }

    fun setAddSubjectDialogOpen(open: Boolean) {
        _uiState.value = _uiState.value.copy(isAddSubjectDialogOpen = open)
    }

    fun setAddChapterDialogOpen(open: Boolean) {
        _uiState.value = _uiState.value.copy(isAddChapterDialogOpen = open)
    }

    fun updateThemeMode(mode: String) {
        val settings = _uiState.value.userSettings ?: return
        viewModelScope.launch {
            repository.updateSettings(settings.copy(themeMode = mode))
        }
    }

    fun toggleNotificationSetting(type: String) {
        val settings = _uiState.value.userSettings ?: return
        val updated = when (type) {
            "10" -> settings.copy(notify10Min = !settings.notify10Min)
            "5" -> settings.copy(notify5Min = !settings.notify5Min)
            "1" -> settings.copy(notify1Min = !settings.notify1Min)
            else -> settings
        }
        viewModelScope.launch {
            repository.updateSettings(updated)
        }
    }

    fun exportProgress(onExportReady: (String) -> Unit) {
        val user = _uiState.value.currentUser ?: return
        viewModelScope.launch {
            val json = repository.exportUserDataAsJson(user.userId)
            onExportReady(json)
            _uiState.value = _uiState.value.copy(snackbarMessage = "Progress exported to clipboard.")
        }
    }

    // AI STUDY ADVISOR
    fun setAiSheetOpen(open: Boolean) {
        _uiState.value = _uiState.value.copy(isAiSheetOpen = open)
    }

    fun askAiAssistant(query: String) {
        val targetUserId = if (_uiState.value.isFriendMode) {
            _uiState.value.friendUser?.userId ?: return
        } else {
            _uiState.value.currentUser?.userId ?: return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isAiLoading = true)
            val answer = repository.queryStudyAdvisor(targetUserId, query)
            _uiState.value = _uiState.value.copy(
                isAiLoading = false,
                aiResponse = answer
            )
        }
    }
}
