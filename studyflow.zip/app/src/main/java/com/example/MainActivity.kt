package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WeeklyHistoryScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.StudyFlowTheme
import com.example.viewmodel.StudyFlowViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: StudyFlowViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsState()

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission(),
                onResult = { _ -> }
            )

            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            val isSystemDark = isSystemInDarkTheme()
            val useDarkTheme = when (uiState.userSettings?.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemDark
            }

            StudyFlowTheme(darkTheme = useDarkTheme) {
                StudyFlowApp(
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun StudyFlowApp(
    viewModel: StudyFlowViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    // Determine current screen
    val currentScreen = when {
        uiState.isSettingsOpen -> "SETTINGS"
        uiState.isWeeklyHistoryOpen -> "WEEKLY_HISTORY"
        uiState.currentUser == null && !uiState.isFriendMode -> "WELCOME"
        else -> "HOME"
    }

    // Handle Back Press
    BackHandler(enabled = currentScreen != "HOME" && currentScreen != "WELCOME") {
        when (currentScreen) {
            "SETTINGS" -> viewModel.setSettingsOpen(false)
            "WEEKLY_HISTORY" -> viewModel.setWeeklyHistoryOpen(false)
            else -> {
                if (uiState.isFriendMode) {
                    viewModel.exitFriendMode()
                }
            }
        }
    }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screenTransition",
        modifier = modifier.fillMaxSize()
    ) { screen ->
        when (screen) {
            "WELCOME" -> {
                WelcomeScreen(
                    errorMessage = uiState.authError,
                    onClearError = { viewModel.clearAuthError() },
                    onRegister = { name, pin -> viewModel.register(name, pin) },
                    onLogin = { name, pin -> viewModel.login(name, pin) },
                    onViewFriend = { name, pin -> viewModel.viewFriendProgress(name, pin) }
                )
            }

            "SETTINGS" -> {
                SettingsScreen(
                    currentUser = uiState.currentUser,
                    userSettings = uiState.userSettings,
                    appConfig = uiState.appConfig,
                    onBack = { viewModel.setSettingsOpen(false) },
                    onThemeSelected = { mode -> viewModel.updateThemeMode(mode) },
                    onToggleNotification = { type -> viewModel.toggleNotificationSetting(type) },
                    onExportProgress = { callback -> viewModel.exportProgress(callback) },
                    onSyncNow = { viewModel.syncNow() },
                    onCheckUpdate = { viewModel.dismissUpdate() },
                    onLogout = { viewModel.logout() }
                )
            }

            "WEEKLY_HISTORY" -> {
                WeeklyHistoryScreen(
                    weeklyHistory = uiState.weeklyHistory,
                    isFriendMode = uiState.isFriendMode,
                    onBack = { viewModel.setWeeklyHistoryOpen(false) },
                    onArchiveWeek = { viewModel.archiveWeek() }
                )
            }

            else -> {
                HomeScreen(
                    uiState = uiState,
                    onToggleSubjectComplete = { record -> viewModel.toggleSubjectComplete(record) },
                    onOpenPartialCompletion = { record -> viewModel.openPartialCompletion(record) },
                    onClosePartialCompletion = { viewModel.closePartialCompletion() },
                    onSavePartialCompletion = { min, notes -> viewModel.savePartialCompletion(min, notes) },
                    onSelectSubject = { subject -> viewModel.selectSubject(subject) },
                    onUpdateChapterStatus = { chapter, status -> viewModel.updateChapterStatus(chapter, status) },
                    onOpenChapterNotes = { chapter -> viewModel.openChapterNotes(chapter) },
                    onCloseChapterNotes = { viewModel.closeChapterNotes() },
                    onSaveChapterNotes = { notes -> viewModel.saveChapterNotes(notes) },
                    onOpenAddSubject = { viewModel.setAddSubjectDialogOpen(true) },
                    onCloseAddSubject = { viewModel.setAddSubjectDialogOpen(false) },
                    onConfirmAddSubject = { subj, mins, notes, time -> viewModel.addSubject(subj, mins, notes, time) },
                    onOpenAddChapter = { viewModel.setAddChapterDialogOpen(true) },
                    onCloseAddChapter = { viewModel.setAddChapterDialogOpen(false) },
                    onConfirmAddChapter = { subj, num, title, notes -> viewModel.addChapter(subj, num, title, notes) },
                    onOpenSettings = { viewModel.setSettingsOpen(true) },
                    onOpenWeeklyHistory = { viewModel.setWeeklyHistoryOpen(true) },
                    onOpenAiAssistant = { viewModel.setAiSheetOpen(true) },
                    onCloseAiAssistant = { viewModel.setAiSheetOpen(false) },
                    onAskAiQuestion = { query -> viewModel.askAiAssistant(query) },
                    onTriggerTestReminder = { subj, mins -> viewModel.triggerTestNotification(subj, mins) },
                    onExitFriendMode = { viewModel.exitFriendMode() },
                    onDismissUpdate = { viewModel.dismissUpdate() },
                    onAcceptUpdate = { viewModel.acceptUpdate() },
                    onClearSnackbar = { viewModel.clearSnackbar() },
                    onSyncNow = { viewModel.syncNow() }
                )
            }
        }
    }
}
