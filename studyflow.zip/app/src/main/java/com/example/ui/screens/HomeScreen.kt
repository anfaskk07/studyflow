package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChapterEntity
import com.example.data.model.StudyRecordEntity
import com.example.data.model.UserEntity
import com.example.ui.components.AddChapterDialog
import com.example.ui.components.AddSubjectDialog
import com.example.ui.components.ChapterNotesDialog
import com.example.ui.components.ChapterTrackerSection
import com.example.ui.components.PartialCompletionDialog
import com.example.ui.components.ProgressSummaryCard
import com.example.ui.components.SubjectTodayCard
import com.example.ui.components.UpdateDialog
import com.example.viewmodel.StudyFlowUiState
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    uiState: StudyFlowUiState,
    onToggleSubjectComplete: (StudyRecordEntity) -> Unit,
    onOpenPartialCompletion: (StudyRecordEntity) -> Unit,
    onClosePartialCompletion: () -> Unit,
    onSavePartialCompletion: (minutes: Int, notes: String) -> Unit,
    onSelectSubject: (String) -> Unit,
    onUpdateChapterStatus: (ChapterEntity, String) -> Unit,
    onOpenChapterNotes: (ChapterEntity) -> Unit,
    onCloseChapterNotes: () -> Unit,
    onSaveChapterNotes: (String) -> Unit,
    onOpenAddSubject: () -> Unit,
    onCloseAddSubject: () -> Unit,
    onConfirmAddSubject: (String, Int, String, String) -> Unit,
    onOpenAddChapter: () -> Unit,
    onCloseAddChapter: () -> Unit,
    onConfirmAddChapter: (String, Int, String, String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenWeeklyHistory: () -> Unit,
    onOpenAiAssistant: () -> Unit,
    onCloseAiAssistant: () -> Unit,
    onAskAiQuestion: (String) -> Unit,
    onTriggerTestReminder: (String, Int) -> Unit,
    onExitFriendMode: () -> Unit,
    onDismissUpdate: () -> Unit,
    onAcceptUpdate: () -> Unit,
    onClearSnackbar: () -> Unit,
    onSyncNow: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            onClearSnackbar()
        }
    }

    val activeUser = if (uiState.isFriendMode) uiState.friendUser else uiState.currentUser
    val userName = activeUser?.name ?: "Student"
    val streakDays = activeUser?.streakCount ?: 12

    // Greeting Calculation
    val calendar = Calendar.getInstance()
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val greetingTime = when {
        hour < 12 -> "Good Morning"
        hour < 17 -> "Good Afternoon"
        else -> "Good Evening"
    }

    // Formatted date (e.g., "Monday, Oct 7")
    val dateFormat = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())
    val currentDateStr = dateFormat.format(Date())

    val completedSubjects = uiState.todayRecords.count { it.status == "COMPLETED" }
    val totalSubjects = uiState.todayRecords.size
    val totalMinutesLogged = uiState.todayRecords.sumOf { it.completedMinutes }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            if (!uiState.isFriendMode) {
                FloatingActionButton(
                    onClick = onOpenAiAssistant,
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.testTag("ai_fab_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "StudyFlow AI Assistant",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("AI Coach", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Friend Mode Read-Only Banner
            if (uiState.isFriendMode) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("friend_mode_banner")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Viewing ${userName}'s StudyFlow",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.surface
                                ) {
                                    Text(
                                        text = "Read-only",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = onExitFriendMode,
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                            ) {
                                Text("Exit", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            // Top Header: Greeting, Date, Streak, Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "$greetingTime, $userName 👋",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentDateStr,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val (statusLabel, statusColor) = when (uiState.connectionState) {
                                com.example.data.SyncConnectionState.SYNCING -> "Syncing..." to Color(0xFFD97706)
                                com.example.data.SyncConnectionState.SYNCED -> "Synced" to Color(0xFF38A169)
                                com.example.data.SyncConnectionState.OFFLINE -> "Offline" to MaterialTheme.colorScheme.onSurfaceVariant
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.clickable { onSyncNow() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(statusColor)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = statusLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = statusColor,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Weekly Analytics icon
                        IconButton(
                            onClick = onOpenWeeklyHistory,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surface)
                                .testTag("weekly_history_icon_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Analytics,
                                contentDescription = "Weekly History",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Settings Icon (Theme switch hidden inside Settings)
                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surface)
                                .testTag("settings_icon_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // Progress Summary Card (4 / 6 completed, 82% weekly, 🔥 12 Day Streak)
            item {
                ProgressSummaryCard(
                    dailyCompleted = completedSubjects,
                    dailyTotal = totalSubjects,
                    weeklyPercentage = 82, // 82% per spec
                    streakDays = streakDays,
                    totalMinutesToday = totalMinutesLogged
                )
            }

            // TODAY CARDS SECTION
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Today's Subjects",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Physics • Chemistry • Botany • Zoology • Maths",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (!uiState.isFriendMode) {
                        OutlinedButton(
                            onClick = onOpenAddSubject,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("add_subject_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            items(uiState.todayRecords, key = { it.id }) { record ->
                SubjectTodayCard(
                    record = record,
                    isFriendMode = uiState.isFriendMode,
                    onToggleComplete = { onToggleSubjectComplete(record) },
                    onOpenEdit = { onOpenPartialCompletion(record) },
                    onTriggerReminder = { minutes -> onTriggerTestReminder(record.subject, minutes) }
                )
            }

            // STUDY PLAN & CHAPTER TRACKING SECTION
            item {
                Spacer(modifier = Modifier.height(6.dp))
                ChapterTrackerSection(
                    chapters = uiState.allChapters,
                    selectedSubject = uiState.selectedSubject,
                    isFriendMode = uiState.isFriendMode,
                    onSelectSubject = onSelectSubject,
                    onUpdateStatus = onUpdateChapterStatus,
                    onEditNotes = onOpenChapterNotes,
                    onAddChapterClick = onOpenAddChapter
                )
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    // Partial Completion Dialog
    uiState.partialRecordToEdit?.let { record ->
        PartialCompletionDialog(
            record = record,
            onDismiss = onClosePartialCompletion,
            onSave = onSavePartialCompletion
        )
    }

    // Chapter Notes Dialog
    uiState.chapterToEditNotes?.let { chapter ->
        ChapterNotesDialog(
            chapter = chapter,
            onDismiss = onCloseChapterNotes,
            onSaveNotes = onSaveChapterNotes
        )
    }

    // Add Subject Dialog
    if (uiState.isAddSubjectDialogOpen) {
        AddSubjectDialog(
            onDismiss = onCloseAddSubject,
            onConfirm = onConfirmAddSubject
        )
    }

    // Add Chapter Dialog
    if (uiState.isAddChapterDialogOpen) {
        AddChapterDialog(
            initialSubject = uiState.selectedSubject,
            onDismiss = onCloseAddChapter,
            onConfirm = onConfirmAddChapter
        )
    }

    // Update Available Dialog
    if (uiState.showUpdateDialog && uiState.appConfig != null) {
        UpdateDialog(
            config = uiState.appConfig,
            isForceUpdate = uiState.isForceUpdate,
            onDismiss = onDismissUpdate,
            onUpdate = onAcceptUpdate
        )
    }

    // AI Assistant Sheet
    if (uiState.isAiSheetOpen) {
        AiAssistantSheet(
            aiResponse = uiState.aiResponse,
            isLoading = uiState.isAiLoading,
            onDismiss = onCloseAiAssistant,
            onAskQuestion = onAskAiQuestion
        )
    }
}
