package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppConfigEntity

@Composable
fun UpdateDialog(
    config: AppConfigEntity?,
    isForceUpdate: Boolean = false,
    onDismiss: () -> Unit,
    onUpdate: () -> Unit
) {
    if (config == null) return

    AlertDialog(
        onDismissRequest = {
            if (!isForceUpdate) onDismiss()
        },
        shape = RoundedCornerShape(22.dp),
        title = {
            Text(
                text = if (isForceUpdate) "Critical Update Required" else config.updateTitle,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        },
        text = {
            Column {
                Text(
                    text = "Version ${config.latestVersion}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "What's new:\n${config.updateDescription}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (isForceUpdate) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "This update is required to continue using StudyFlow safely.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onUpdate,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("update_confirm_button")
            ) {
                Text("Update")
            }
        },
        dismissButton = {
            if (!isForceUpdate) {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("update_later_button")
                ) {
                    Text("Later")
                }
            }
        }
    )
}
