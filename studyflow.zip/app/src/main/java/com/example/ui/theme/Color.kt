package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// StudyFlow Theme Colors specified by User:
// Light: Background: #F5F7FA, Card: #FFFFFF, Accent: #5B67F1
// Dark: Background: #111318, Card: #1B1E24, Accent: #7C87FF

// Light Palette
val BackgroundLight = Color(0xFFF5F7FA)
val CardLight = Color(0xFFFFFFFF)
val AccentLight = Color(0xFF5B67F1)
val AccentSoftLight = Color(0xFFEEF0FD)
val TextPrimaryLight = Color(0xFF191D24)
val TextSecondaryLight = Color(0xFF6B7280)
val TextTertiaryLight = Color(0xFF9CA3AF)
val OutlineLight = Color(0xFFE5E7EB)
val CardBorderLight = Color(0xFFEDF0F5)

// Dark Palette
val BackgroundDark = Color(0xFF111318)
val CardDark = Color(0xFF1B1E24)
val AccentDark = Color(0xFF7C87FF)
val AccentSoftDark = Color(0xFF262A42)
val TextPrimaryDark = Color(0xFFF3F4F8)
val TextSecondaryDark = Color(0xFF9DA4B0)
val TextTertiaryDark = Color(0xFF6B7280)
val OutlineDark = Color(0xFF282C36)
val CardBorderDark = Color(0xFF262A34)

// Functional Status Colors (Muted, elegant, strictly non-garish)
val StatusCompletedLight = Color(0xFF38A169)
val StatusCompletedSoftLight = Color(0xFFE6F4EA)
val StatusPartialLight = Color(0xFFD97706)
val StatusPartialSoftLight = Color(0xFFFEF3C7)
val StatusNotStartedLight = Color(0xFF6B7280)
val StatusNotStartedSoftLight = Color(0xFFF3F4F6)

val StatusCompletedDark = Color(0xFF48BB78)
val StatusCompletedSoftDark = Color(0xFF1E3A2B)
val StatusPartialDark = Color(0xFFF59E0B)
val StatusPartialSoftDark = Color(0xFF3B2E15)
val StatusNotStartedDark = Color(0xFF9CA3AF)
val StatusNotStartedSoftDark = Color(0xFF242832)

val FlameStreakColor = Color(0xFFFF6D3B)
val FlameStreakSoft = Color(0xFFFFECE5)
