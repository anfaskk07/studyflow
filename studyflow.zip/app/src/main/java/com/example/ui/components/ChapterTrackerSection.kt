package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ChapterEntity
import com.example.ui.theme.StatusCompletedDark
import com.example.ui.theme.StatusCompletedLight
import com.example.ui.theme.StatusCompletedSoftDark
import com.example.ui.theme.StatusCompletedSoftLight
import com.example.ui.theme.StatusNotStartedDark
import com.example.ui.theme.StatusNotStartedLight
import com.example.ui.theme.StatusNotStartedSoftDark
import com.example.ui.theme.StatusNotStartedSoftLight
import com.example.ui.theme.StatusPartialDark
import com.example.ui.theme.StatusPartialLight
import com.example.ui.theme.StatusPartialSoftDark
import com.example.ui.theme.StatusPartialSoftLight

@Composable
fun ChapterTrackerSection(
    chapters: List<ChapterEntity>,
    selectedSubject: String,
    isFriendMode: Boolean,
    onSelectSubject: (String) -> Unit,
    onUpdateStatus: (chapter: ChapterEntity, newStatus: String) -> Unit,
    onEditNotes: (chapter: ChapterEntity) -> Unit,
    onAddChapterClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Unique subjects from chapters list or fallback
    val subjectsList = listOf("Maths", "Chemistry", "Botany", "Zoology", "Physics")
        .plus(chapters.map { it.subject })
        .distinct()

    val filteredChapters = chapters.filter { it.subject.equals(selectedSubject, ignoreCase = true) }
        .sortedBy { it.chapterNumber }

    val completedCount = filteredChapters.count { it.status == "COMPLETED" }
    val totalCount = filteredChapters.size

    Column(modifier = modifier.fillMaxWidth()) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Study Plan & Chapters",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (totalCount > 0) "$completedCount / $totalCount chapters completed" else "Track syllabus progress",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (!isFriendMode) {
                OutlinedButton(
                    onClick = onAddChapterClick,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("add_chapter_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Chapter",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Horizontal Subject Selector Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            subjectsList.forEach { subject ->
                val isSelected = subject.equals(selectedSubject, ignoreCase = true)
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectSubject(subject) },
                    label = { Text(subject) },
                    shape = RoundedCornerShape(12.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("subject_chip_${subject.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Chapters List
        if (filteredChapters.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No chapters recorded yet for $selectedSubject.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                filteredChapters.forEach { chapter ->
                    ChapterItemCard(
                        chapter = chapter,
                        isFriendMode = isFriendMode,
                        onCompleteClick = {
                            val newStatus = if (chapter.status == "COMPLETED") "NOT_STARTED" else "COMPLETED"
                            onUpdateStatus(chapter, newStatus)
                        },
                        onPauseClick = {
                            val newStatus = if (chapter.status == "PAUSED") "NOT_STARTED" else "PAUSED"
                            onUpdateStatus(chapter, newStatus)
                        },
                        onNotesClick = { onEditNotes(chapter) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChapterItemCard(
    chapter: ChapterEntity,
    isFriendMode: Boolean,
    onCompleteClick: () -> Unit,
    onPauseClick: () -> Unit,
    onNotesClick: () -> Unit
) {
    val isCompleted = chapter.status == "COMPLETED"
    val isPaused = chapter.status == "PAUSED"
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    val badgeBg = when {
        isCompleted -> if (isDark) StatusCompletedSoftDark else StatusCompletedSoftLight
        isPaused -> if (isDark) StatusPartialSoftDark else StatusPartialSoftLight
        else -> if (isDark) StatusNotStartedSoftDark else StatusNotStartedSoftLight
    }

    val badgeColor = when {
        isCompleted -> if (isDark) StatusCompletedDark else StatusCompletedLight
        isPaused -> if (isDark) StatusPartialDark else StatusPartialLight
        else -> if (isDark) StatusNotStartedDark else StatusNotStartedLight
    }

    val statusText = when {
        isCompleted -> "Completed"
        isPaused -> "Paused"
        else -> "Not Started"
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chapter_item_${chapter.chapterNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Chapter number circular badge
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(badgeBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${chapter.chapterNumber}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = badgeColor
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = chapter.chapterTitle,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Status: $statusText",
                            style = MaterialTheme.typography.labelSmall,
                            color = badgeColor,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Action buttons: ✓ Complete, ⏸ Pause, ✏ Add Notes
                if (!isFriendMode) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Complete Action
                        ActionIconButton(
                            label = "Complete",
                            icon = Icons.Default.Check,
                            isActive = isCompleted,
                            activeColor = badgeColor,
                            onClick = onCompleteClick
                        )

                        // Pause Action
                        ActionIconButton(
                            label = "Pause",
                            icon = Icons.Default.Pause,
                            isActive = isPaused,
                            activeColor = Color(0xFFD97706),
                            onClick = onPauseClick
                        )

                        // Notes Action
                        ActionIconButton(
                            label = "Notes",
                            icon = Icons.Default.Edit,
                            isActive = chapter.notes.isNotBlank(),
                            activeColor = MaterialTheme.colorScheme.primary,
                            onClick = onNotesClick
                        )
                    }
                }
            }

            // Chapter notes display if any
            AnimatedVisibility(visible = chapter.notes.isNotBlank()) {
                Column {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "📌 ${chapter.notes}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionIconButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isActive) activeColor.copy(alpha = 0.15f) else Color.Transparent)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isActive) activeColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.size(16.dp)
        )
    }
}
