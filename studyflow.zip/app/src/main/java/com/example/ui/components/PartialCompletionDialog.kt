package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.StudyRecordEntity

@Composable
fun PartialCompletionDialog(
    record: StudyRecordEntity,
    onDismiss: () -> Unit,
    onSave: (minutes: Int, notes: String) -> Unit
) {
    var minutesText by remember { mutableStateOf(record.completedMinutes.toString()) }
    var notesText by remember { mutableStateOf(record.notes) }
    var sliderValue by remember {
        mutableFloatStateOf(record.completedMinutes.toFloat().coerceIn(0f, record.targetMinutes.toFloat()))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(22.dp),
        title = {
            Column {
                Text(
                    text = "Log Study Progress",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${record.subject} (Target: ${record.targetMinutes} mins)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Minutes Input
                OutlinedTextField(
                    value = minutesText,
                    onValueChange = { input ->
                        val digits = input.filter { it.isDigit() }.take(4)
                        minutesText = digits
                        val parsed = digits.toIntOrNull() ?: 0
                        sliderValue = parsed.toFloat().coerceIn(0f, record.targetMinutes.toFloat())
                    },
                    label = { Text("Completed Minutes") },
                    placeholder = { Text("e.g. 60") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("minutes_input")
                )

                // Quick increment presets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(15, 30, 45, 60, record.targetMinutes).distinct().forEach { preset ->
                        FilterChip(
                            selected = minutesText == preset.toString(),
                            onClick = {
                                minutesText = preset.toString()
                                sliderValue = preset.toFloat().coerceIn(0f, record.targetMinutes.toFloat())
                            },
                            label = { Text("${preset}m") }
                        )
                    }
                }

                // Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "0 min",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${record.targetMinutes} min",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Slider(
                        value = sliderValue,
                        onValueChange = {
                            sliderValue = it
                            minutesText = it.toInt().toString()
                        },
                        valueRange = 0f..record.targetMinutes.toFloat(),
                        steps = 5,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Notes Input (e.g., "Stopped at Chapter 4")
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Session Notes") },
                    placeholder = { Text("e.g. Stopped at Chapter 4") },
                    minLines = 2,
                    maxLines = 4,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("notes_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalMinutes = minutesText.toIntOrNull() ?: 0
                    onSave(finalMinutes, notesText)
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("save_progress_button")
            ) {
                Text("Save Progress")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Cancel")
            }
        }
    )
}
