package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.StudyRecordEntity
import com.example.ui.theme.StatusCompletedDark
import com.example.ui.theme.StatusCompletedLight
import com.example.ui.theme.StatusCompletedSoftDark
import com.example.ui.theme.StatusCompletedSoftLight
import com.example.ui.theme.StatusNotStartedDark
import com.example.ui.theme.StatusNotStartedLight
import com.example.ui.theme.StatusNotStartedSoftDark
import com.example.ui.theme.StatusNotStartedSoftLight
import com.example.ui.theme.StatusPartialDark
import com.example.ui.theme.StatusPartialLight
import com.example.ui.theme.StatusPartialSoftDark
import com.example.ui.theme.StatusPartialSoftLight

@Composable
fun SubjectTodayCard(
    record: StudyRecordEntity,
    isFriendMode: Boolean,
    onToggleComplete: () -> Unit,
    onOpenEdit: () -> Unit,
    onTriggerReminder: (minutesBefore: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val isCompleted = record.status == "COMPLETED"
    val isPartial = record.status == "PARTIAL" || record.status == "PARTIALLY_COMPLETED"

    val fraction = if (record.targetMinutes > 0) {
        (record.completedMinutes.toFloat() / record.targetMinutes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    val badgeBg = when {
        isCompleted -> if (isDark) StatusCompletedSoftDark else StatusCompletedSoftLight
        isPartial -> if (isDark) StatusPartialSoftDark else StatusPartialSoftLight
        else -> if (isDark) StatusNotStartedSoftDark else StatusNotStartedSoftLight
    }

    val badgeTextColor = when {
        isCompleted -> if (isDark) StatusCompletedDark else StatusCompletedLight
        isPartial -> if (isDark) StatusPartialDark else StatusPartialLight
        else -> if (isDark) StatusNotStartedDark else StatusNotStartedLight
    }

    val badgeText = when {
        isCompleted -> "Completed"
        isPartial -> "Partially Completed"
        else -> "Not Completed"
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("subject_card_${record.subject.lowercase()}"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        shadowElevation = 0.5.dp
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            // Header row: Subject Name, Scheduled time, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Checkbox trigger
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (isCompleted) badgeTextColor else Color.Transparent)
                            .clickable(enabled = !isFriendMode) { onToggleComplete() }
                            .then(
                                if (!isCompleted) Modifier.background(
                                    MaterialTheme.colorScheme.surfaceVariant,
                                    CircleShape
                                ) else Modifier
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Completed",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Outlined.Circle,
                                contentDescription = "Not Completed",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = record.subject,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = record.scheduledTime,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Status chip
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = badgeBg
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = badgeTextColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Time & Progress: e.g. "60 / 90 minutes completed"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${record.completedMinutes} / ${record.targetMinutes} minutes completed",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${(fraction * 100).toInt()}%",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (isCompleted) badgeTextColor else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                strokeCap = StrokeCap.Round
            )

            // Notes Section (e.g. "Stopped at Chapter 4")
            AnimatedVisibility(visible = record.notes.isNotBlank()) {
                Column {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📝 ${record.notes}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Interactive Bottom Bar
            if (!isFriendMode) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Quick log / edit button
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onOpenEdit() }
                            .padding(vertical = 4.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Log Minutes & Notes",
                            modifier = Modifier.size(15.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Log Time / Notes",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Test Reminder alerts
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Remind: ",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        ReminderChip(label = "10m") { onTriggerReminder(10) }
                        Spacer(modifier = Modifier.width(4.dp))
                        ReminderChip(label = "5m") { onTriggerReminder(5) }
                        Spacer(modifier = Modifier.width(4.dp))
                        ReminderChip(label = "1m") { onTriggerReminder(1) }
                        Spacer(modifier = Modifier.width(4.dp))
                        ReminderChip(label = "Now") { onTriggerReminder(0) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReminderChip(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
