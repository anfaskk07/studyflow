package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun AddSubjectDialog(
    onDismiss: () -> Unit,
    onConfirm: (subject: String, targetMinutes: Int, notes: String, time: String) -> Unit
) {
    var subjectName by remember { mutableStateOf("") }
    var targetMinutesText by remember { mutableStateOf("60") }
    var notesText by remember { mutableStateOf("") }
    var timeText by remember { mutableStateOf("03:00 PM") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(22.dp),
        title = {
            Text(
                text = "Add Today's Subject",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = subjectName,
                    onValueChange = { subjectName = it },
                    label = { Text("Subject Name") },
                    placeholder = { Text("e.g. Zoology, English") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("new_subject_name_input")
                )
                OutlinedTextField(
                    value = targetMinutesText,
                    onValueChange = { targetMinutesText = it.filter { c -> c.isDigit() } },
                    label = { Text("Target Minutes") },
                    placeholder = { Text("e.g. 60") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeText,
                    onValueChange = { timeText = it },
                    label = { Text("Scheduled Time") },
                    placeholder = { Text("e.g. 05:00 PM") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Initial Topic / Notes") },
                    placeholder = { Text("e.g. Read chapters 3 & 4") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (subjectName.isNotBlank()) {
                        val mins = targetMinutesText.toIntOrNull() ?: 60
                        onConfirm(subjectName.trim(), mins, notesText.trim(), timeText.trim())
                    }
                },
                enabled = subjectName.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("confirm_add_subject_btn")
            ) {
                Text("Add Subject")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(14.dp)) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddChapterDialog(
    initialSubject: String,
    onDismiss: () -> Unit,
    onConfirm: (subject: String, chapterNumber: Int, title: String, notes: String) -> Unit
) {
    var subject by remember { mutableStateOf(initialSubject) }
    var chapterNumberText by remember { mutableStateOf("1") }
    var chapterTitle by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(22.dp),
        title = {
            Text(
                text = "Add Chapter to Plan",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = chapterNumberText,
                    onValueChange = { chapterNumberText = it.filter { c -> c.isDigit() } },
                    label = { Text("Chapter Number") },
                    placeholder = { Text("e.g. 5") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = chapterTitle,
                    onValueChange = { chapterTitle = it },
                    label = { Text("Chapter Title") },
                    placeholder = { Text("e.g. Electrochemistry") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Notes / Formula Reminders") },
                    placeholder = { Text("e.g. Focus on exercise problems") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (chapterTitle.isNotBlank()) {
                        val num = chapterNumberText.toIntOrNull() ?: 1
                        onConfirm(subject.trim(), num, chapterTitle.trim(), notesText.trim())
                    }
                },
                enabled = chapterTitle.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("confirm_add_chapter_btn")
            ) {
                Text("Add Chapter")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(14.dp)) {
                Text("Cancel")
            }
        }
    )
}
