package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "studyflow_reminders"
        const val CHANNEL_NAME = "StudyFlow Reminders"
        const val CHANNEL_DESC = "Local study schedule reminders that operate offline"
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
                enableVibration(true)
            }
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun sendReminder(
        subject: String,
        minutesBefore: Int, // 10, 5, 1, or 0 (now)
        scheduledTime: String = ""
    ) {
        val title = when (minutesBefore) {
            10 -> "📚 $subject starts in 10 minutes"
            5 -> "⚡ $subject starts in 5 minutes"
            1 -> "🚀 $subject starts in 1 minute"
            else -> "🎯 $subject starts now"
        }

        val message = if (minutesBefore == 0) {
            "Time to focus! Your $subject session is starting."
        } else {
            "Get your materials ready. $subject session scheduled for $scheduledTime."
        }

        try {
            val notificationId = (subject.hashCode() + minutesBefore + (System.currentTimeMillis() % 1000).toInt()).coerceAtLeast(1)
            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            val manager = NotificationManagerCompat.from(context)
            manager.notify(notificationId, builder.build())
        } catch (_: SecurityException) {
            // Handled if permission not granted
        }
    }
}
