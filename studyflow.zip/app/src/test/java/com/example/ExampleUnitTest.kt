package com.example

import com.example.data.SecurityUtils
import com.example.data.model.AppConfigEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testPinHashingAndVerification() {
        val pin = "AB12"
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPin(pin, salt)

        // Hash must not equal plain PIN
        assertNotEquals(pin, hash)

        // Verify correct PIN passes
        assertTrue(SecurityUtils.verifyPin("AB12", salt, hash))
        // Case-insensitivity support
        assertTrue(SecurityUtils.verifyPin("ab12", salt, hash))

        // Incorrect PIN must fail
        assertFalse(SecurityUtils.verifyPin("XY89", salt, hash))
        assertFalse(SecurityUtils.verifyPin("0000", salt, hash))
    }

    @Test
    fun testPinLookupHashing() {
        val h1 = SecurityUtils.hashPinForLookup("XY89")
        val h2 = SecurityUtils.hashPinForLookup("xy89")
        val h3 = SecurityUtils.hashPinForLookup("AB12")

        assertEquals(h1, h2)
        assertNotEquals(h1, h3)
    }

    @Test
    fun testCompositeFriendLookupKey() {
        val key1 = SecurityUtils.generateFriendLookupKey("Student One", "AB12")
        val key2 = SecurityUtils.generateFriendLookupKey("student one", "ab12")
        val key3 = SecurityUtils.generateFriendLookupKey("Student Two", "AB12")
        val key4 = SecurityUtils.generateFriendLookupKey("Student One", "CD34")

        // Case-insensitive normalization must produce identical lookup key
        assertEquals(key1, key2)
        // Different student name with same PIN must produce completely distinct key
        assertNotEquals(key1, key3)
        // Same student name with different PIN must produce distinct key
        assertNotEquals(key1, key4)
    }

    @Test
    fun testAppConfigVersionComparison() {
        val normalUpdate = AppConfigEntity(
            id = 1,
            currentVersion = "2.0.0",
            latestVersion = "2.1.0",
            minimumSupportedVersion = "1.8.0"
        )
        assertTrue(normalUpdate.isUpdateAvailable())
        assertFalse(normalUpdate.isForceUpdateRequired())

        val forceUpdate = AppConfigEntity(
            id = 1,
            currentVersion = "1.5.0",
            latestVersion = "2.1.0",
            minimumSupportedVersion = "2.0.0"
        )
        assertTrue(forceUpdate.isUpdateAvailable())
        assertTrue(forceUpdate.isForceUpdateRequired())

        val upToDate = AppConfigEntity(
            id = 1,
            currentVersion = "2.1.0",
            latestVersion = "2.1.0",
            minimumSupportedVersion = "2.0.0"
        )
        assertFalse(upToDate.isUpdateAvailable())
        assertFalse(upToDate.isForceUpdateRequired())
    }

    @Test
    fun testStudyRecordCompletionLogic() {
        // Full completion
        val fullRecord = com.example.data.model.StudyRecordEntity(
            id = 1,
            userId = "user_123",
            subject = "Physics",
            date = "2026-10-07",
            targetMinutes = 90,
            completedMinutes = 90,
            status = "COMPLETED",
            notes = "Finished all questions"
        )
        assertEquals("COMPLETED", fullRecord.status)
        assertEquals(90, fullRecord.completedMinutes)
        assertEquals("Finished all questions", fullRecord.notes)

        // Partial completion
        val partialRecord = fullRecord.copy(
            id = 2,
            completedMinutes = 45,
            status = "PARTIAL",
            notes = "Stopped at Chapter 4"
        )
        assertEquals("PARTIAL", partialRecord.status)
        assertEquals(45, partialRecord.completedMinutes)
        assertEquals("Stopped at Chapter 4", partialRecord.notes)
    }

    @Test
    fun testUserLockoutCalculation() {
        val now = 1000000L
        val activeUser = com.example.data.model.UserEntity(
            userId = "test_user",
            name = "Student",
            pinHash = "hash",
            pinSalt = "salt",
            pinLookupHash = "lookup",
            failedAttempts = 5,
            lockoutUntilMs = now + 30000L
        )

        // Lockout must be active when current time is before lockoutUntilMs
        assertTrue(activeUser.lockoutUntilMs > now)
        val remainingSeconds = (activeUser.lockoutUntilMs - now) / 1000
        assertEquals(30L, remainingSeconds)

        // Lockout cleared
        val unlockedUser = activeUser.copy(failedAttempts = 0, lockoutUntilMs = 0L)
        assertFalse(unlockedUser.lockoutUntilMs > now)
    }

    @Test
    fun testSyncQueuePayloadIntegrity() {
        val mutation = com.example.data.model.SyncQueueEntity(
            id = 1,
            userId = "user_abc",
            entityType = "STUDY_RECORD",
            entityId = "record_456",
            operation = "UPDATE",
            payloadJson = "{\"completedMinutes\":60,\"notes\":\"Stopped at page 30\"}",
            createdAt = System.currentTimeMillis()
        )
        assertEquals("user_abc", mutation.userId)
        assertEquals("STUDY_RECORD", mutation.entityType)
        assertEquals("record_456", mutation.entityId)
        assertEquals("UPDATE", mutation.operation)
        assertTrue(mutation.payloadJson.contains("completedMinutes"))
    }
}
